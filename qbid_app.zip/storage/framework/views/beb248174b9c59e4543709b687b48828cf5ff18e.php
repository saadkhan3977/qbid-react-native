<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\frank_mombe\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>