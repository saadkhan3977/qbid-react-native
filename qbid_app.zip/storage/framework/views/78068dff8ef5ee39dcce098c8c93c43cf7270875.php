
Hi <?php echo e($data['fname']); ?>,

Thank you for being a part of our Pay Me First community. Can you believe that it’s been 9 months since you first joined? We hope you’ve been able to enjoy all the benefits of your Pay Me First membership these past months.


RENEW NOW

If you have any questions or suggestions, please don’t hesitate to reach out at [email] or [phone] to see how we can meet your needs. We’d love to hear your feedback!

Best,
[YOUR SIGNATURE]
<?php /**PATH /var/www/vhosts/thirsty-shirley.23-83-37-162.plesk.page/amazing-grothendieck.23-83-37-162.plesk.page/resources/views/mail.blade.php ENDPATH**/ ?>