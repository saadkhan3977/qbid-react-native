<?php echo e($slot); ?>

<?php /**PATH D:\laragon\www\qbid_app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>