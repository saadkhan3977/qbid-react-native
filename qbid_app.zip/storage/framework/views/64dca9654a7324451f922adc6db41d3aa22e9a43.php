<?php echo e($slot); ?>

<?php /**PATH /var/www/vhosts/thirsty-shirley.23-83-37-162.plesk.page/amazing-grothendieck.23-83-37-162.plesk.page/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>