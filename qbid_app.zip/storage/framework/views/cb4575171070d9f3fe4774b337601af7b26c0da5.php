

<?php $__env->startSection('title', 'Terms And Contions'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                    <!-- left column -->
                <div class="col-md-12">
                        <!-- jquery validation -->
                    <div class="card card-secondary">
                        <div class="card-header">
                            <h3 class="card-title">Terms <small> & </small>Conditions</h3>
                        </div>
                        <!-- /.card-header -->
                        <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="btn btn-danger"><?php echo e($e); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <!-- form start -->
                        <form action="<?php echo e(route('terms_conditions_post')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input name="id" type="hidden" class="form-control" value="<?php echo e(($data)?$data->id :''); ?>" placeholder="Enter ...">
                            
                            <div class="card-body">

                                <div class="row">
                                    <div class="col-sm-4">
                                    <div class="form-group">
                                        <label>Effective Date</label>
                                        <input name="effective_date" type="date" class="form-control" value="<?php echo e(($data)?$data->effective_date :''); ?>"  required>
                                    </div>
                                    </div>
                             
                                                                 
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="description" class="form-control summernote" required><?php echo e(($data)?$data->description :''); ?></textarea>
                                    </div>
                                    </div>
                                    </div>

                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-success float-sm-right">
                                  + SAVE
                                </button>
                                <button type="button" class="btn btn-danger float-sm-left" onclick="location.href='<?php echo e(route('guides.index')); ?>';">
                                    <i class="fas fa-reply"></i>  Back
                                </button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
                <!--/.col (left) -->
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\paymefirst\resources\views/admin/termsandcontions/edit.blade.php ENDPATH**/ ?>