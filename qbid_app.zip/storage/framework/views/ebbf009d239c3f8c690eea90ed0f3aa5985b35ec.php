  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2022-2032 >Pay Me First</strong>
    All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo e(asset('admin')); ?>/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('admin')); ?>/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('admin/plugins/summernote/summernote.min.js')); ?>"></script>


<!-- AdminLTE App -->
<script src="<?php echo e(asset('admin')); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="<?php echo e(asset('admin')); ?>/dist/js/demo.js"></script> -->
<script src="<?php echo e(asset('admin/dist/js/pages/dashboard2.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script>
  <?php if(Session::has('success')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.success("<?php echo e(session('success')); ?>");
  <?php endif; ?>

  <?php if(Session::has('error')): ?>
  toastr.options =
  {
  	"closeButton" : true,
  	"progressBar" : true
  }
  		toastr.error("<?php echo e(session('error')); ?>");
  <?php endif; ?>


</script>
<script>
  $(document).ready(function(){
    $(".summernote").summernote();
  });
</script>
</body>
</html>
<?php /**PATH /var/www/vhosts/thirsty-shirley.23-83-37-162.plesk.page/amazing-grothendieck.23-83-37-162.plesk.page/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>