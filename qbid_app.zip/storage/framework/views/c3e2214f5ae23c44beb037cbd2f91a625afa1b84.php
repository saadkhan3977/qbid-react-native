<?php $__env->startComponent('mail::message'); ?>
<h1>We have received your request to verify your Email</h1>
<p>You can use the following code to verify your Email:</p>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo e($code); ?>

<?php echo $__env->renderComponent(); ?>

<p>The allowed duration of the code is one hour from the time the message was sent</p>
<?php echo $__env->renderComponent(); ?><?php /**PATH /var/www/vhosts/thirsty-shirley.23-83-37-162.plesk.page/amazing-grothendieck.23-83-37-162.plesk.page/resources/views/send-code-verify-email.blade.php ENDPATH**/ ?>