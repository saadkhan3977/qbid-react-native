

<?php $__env->startSection('title', 'Transaction'); ?>
<?php $__env->startSection('content'); ?>
  <link href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
 
        <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">DataTable with minimal features & hover style</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
	        <table id="myTable" class="table table-bordered table-responsive table-striped">

                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>User</th>
                        <th>Amount</th>
                        <th width="900">Date</th>
                        <th>Type</th>
                        <th style="width:100%">Reason</th>
                        <th>Status</th>

                    </tr>
                </thead>

                <tbody>
                    <?php if( count($transaction) > 0): ?>
                    <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($val->id); ?></td>
                         
                            <td><?php echo e($val->user->email); ?></td>
                   
                            <td><?php echo e($val->amount); ?></td>
                            <td><?php echo e($val->date); ?></td>
                            <td><?php echo e($val->type); ?></td>
                            <td><?php echo e($val->reason); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary <?php if($val->status == 'Pending'): ?> dropdown-toggle <?php endif; ?>" type="button" <?php if($val->status == 'Pending'): ?> id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"   <?php endif; ?>>
                                    <?php echo e($val->status); ?>

                                    </button>
                                    
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item" href="<?php echo e(route('transaction_status',$val->id)); ?>?status=Approved">Approved</a>
                                        <!-- <a class="dropdown-item" href="#">Pending</a> -->
                                    </div>
                                </div>
                            </td>
                      
                            <!-- <td>
                                <div class="btn-group btn-group-sm dtr-data-2">
                                    <form action="<?php echo e(route('guides.destroy',$val->id)); ?>" method="Post">
                                        <?php echo method_field('DELETE'); ?>    
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger" type="submit" onclic="return confirm('Are You Sure Want To D')"><i class="fas fa-trash"></i> </button>
                                    </from>
                                </div>

                            </td> -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        No Record Found
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
	    </div>
	   
	  <!-- /.card-body -->
    </div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>

<script>
    $('#myTable').DataTable();
</script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\paymefirst\resources\views/admin/transaction.blade.php ENDPATH**/ ?>