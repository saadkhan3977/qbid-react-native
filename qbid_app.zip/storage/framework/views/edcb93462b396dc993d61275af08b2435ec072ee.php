

<?php $__env->startSection('title', 'Guides'); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
	    <div class="card-header">
	        <h3 class="card-title">Guide list</h3>
            <div class="float-sm-right">
                <button type="button" class="btn btn-block btn-outline-info btn-sm" onclick="location.href='<?php echo e(route('guides.create')); ?>';">
                    <i class="fas fa-plus"></i>
                    Create
                </button>
            </div>
	    </div>
	    <!-- /.card-header -->
        <div class="card-body">
	        <table id="example1" class="table table-bordered table-responsive table-striped">

                <thead>
                    <tr>
                        <th>#</th>
                        <th>Question</th>
                        <th>Description</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if( count($guides) > 0): ?>
                    <?php $__currentLoopData = $guides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>S.No :: <?php echo e($val->id); ?></td>
                         
                            <td>
                                <?php echo e($val->question); ?>

                            </td>
                   
                            <td>
                            <?php echo e($val->description); ?>

                            </td>
                      
                            <td>
                                <div class="btn-group btn-group-sm dtr-data-2">
                                    <a href="<?php echo e(route('guides.edit',$val->id)); ?>" class="btn btn-info"><i class="fas fa-pencil-alt"></i></a>
                                    <form action="<?php echo e(route('guides.destroy',$val->id)); ?>" method="Post">
                                        <?php echo method_field('DELETE'); ?>    
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-danger" type="submit"><i class="fas fa-trash"></i> </button>
                                    </from>
                                </div>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <tr>
                        No Record Found
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
	    </div>
	    <style>
	    
.dtr-data-2 a,
.dtr-data-2 button{
     margin:3px 5px;
}
	    </style>
	  <!-- /.card-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\paymefirst\resources\views/admin/guides/index.blade.php ENDPATH**/ ?>